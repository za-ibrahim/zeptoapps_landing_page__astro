declare module 'astro:assets' {
	/** @internal */
	export type FontFamily = (["--font-poppins"])[number];
}
